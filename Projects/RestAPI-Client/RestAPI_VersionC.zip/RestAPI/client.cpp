#include <cstdlib>     /* exit, atoi, malloc, free */
#include <netdb.h>      /* struct hostent, gethostbyname */
#include <arpa/inet.h>
#include <iostream>
#include "utils.h"
#include "requests.h"
#include "connection.h"

int main(int argc, char *argv[]) {
    int port = HTTPALT;
    int sockfd;
    string cookies;
    string jwtToken;

    const char* contentType = "application/json";
    const char* host = "ec2-3-8-116-10.eu-west-2.compute.amazonaws.com";
    char* addr = inet_ntoa((in_addr)*((in_addr *)gethostbyname(host)->h_addr_list[0]));

    while (true) {
        string command;
        getline(cin, command);
        command = TrimTrailingWhitespace(command);

        if (command == "register") {
            json registerMsg;
            string username, password;
            const char* url = "/api/v1/tema/auth/register";

            cout << "username=";
            getline(cin, username);
            cout << "password=";
            getline(cin, password);
            username = TrimTrailingWhitespace(username);
            password = TrimTrailingWhitespace(password);
            registerMsg["username"] = username;
            registerMsg["password"] = password;

            char* request = ComputePostRequest(host, url, contentType,
                    registerMsg.dump(), "", "");
            sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
            SendToServer(sockfd, request);
            char* reply = ReceiveFromServer(sockfd);

            if (strstr(reply, "error")) {
                cout << "Username \"" << username << "\" is already taken." << endl;
            } else {
                cout << "Registered account \"" << username << "\"." << endl;
            }

            CloseConnection(sockfd);
            FreeBuffers(request, reply);
        } else if (command == "login") {
            json loginMsg;
            string username, password;
            const char* url = "/api/v1/tema/auth/login";

            cout << "username=";
            getline(cin, username);
            cout << "password=";
            getline(cin, password);
            username = TrimTrailingWhitespace(username);
            password = TrimTrailingWhitespace(password);
            loginMsg["username"] = username;
            loginMsg["password"] = password;

            char* request = ComputePostRequest(host, url, contentType,
                    loginMsg.dump(), "", "");
            sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
            SendToServer(sockfd, request);
            char* reply = ReceiveFromServer(sockfd);

            if (char* cookie = strstr(reply, "connect")) {
                char* token = strtok(cookie, ";");
                cookies = token;
                cout << "Logged in." << endl;
            } else if (strstr(reply, "No account")) {
                cout << "No account using \"" << username << "\" as username." << endl;
            } else if (strstr(reply, "Credentials are")) {
                cout << "You have entered an invalid username or password." << endl;
            }
            CloseConnection(sockfd);
            FreeBuffers(request, reply);
        } else if (command == "enter_library") {
            const char* url = "/api/v1/tema/library/access";
            char* request = ComputeGetRequest(host, url, cookies, "");
            sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
            SendToServer(sockfd, request);
            char* reply = ReceiveFromServer(sockfd);

            if (char* jwtTokenTemp = strstr(reply, "token")) {
                char* token = strtok(jwtTokenTemp + strlen("token\":\""), "\"");
                jwtToken = token;
                cout << "Access to library granted." << endl;
            } else {
                cout << "Cannot grant access to library." << endl;
            }
            CloseConnection(sockfd);
            FreeBuffers(request, reply);
        } else if (command == "get_books") {
            const char* url = "/api/v1/tema/library/books";

            char* request = ComputeGetRequest(host, url, "", jwtToken);
            sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
            SendToServer(sockfd, request);
            char* reply = ReceiveFromServer(sockfd);

            if (strstr(reply, "error")) {
                cout << "You do not have access to the library." << endl;
            } else {
                PrintBooks(reply);
            }
            CloseConnection(sockfd);
            FreeBuffers(request, reply);
        } else if (command == "get_book") {
            string id;
            cout << "id=";
            getline(cin, id);
            id = TrimTrailingWhitespace(id);

            if (IsNumeric(id)) {
                char* url = (char* )calloc(URLMAXLEN, sizeof(char));
                sprintf(url, "/api/v1/tema/library/books/%s", id.c_str());

                char* request = ComputeGetRequest(host, (const char* ) url, "", jwtToken);
                sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
                SendToServer(sockfd, request);
                char* reply = ReceiveFromServer(sockfd);

                if (strstr(reply, "No book")) {
                    cout << "No book with id \"" << id << "\" was found." << endl;
                } else if (strstr(reply, "error")) {
                    cout << "You do not have access to the library." << endl;
                } else {
                    PrintBookInfo(reply, id);
                }

                CloseConnection(sockfd);
                FreeBuffers(request, reply);
                free(url);
            } else {
                cout << "Book Id should be a numeric input." << endl;
            }
        } else if (command == "add_book") {
            json addBookMsg;
            string title, author, genre, publisher, page_count;
            const char* url = "/api/v1/tema/library/books";

            cout << "title=";
            getline(cin, title);
            cout << "author=";
            getline(cin, author);
            cout << "genre=";
            getline(cin, genre);
            cout << "publisher=";
            getline(cin, publisher);
            cout << "page_count=";
            getline(cin, page_count);
            title = TrimTrailingWhitespace(title);
            author = TrimTrailingWhitespace(author);
            genre = TrimTrailingWhitespace(genre);
            publisher = TrimTrailingWhitespace(publisher);
            page_count = TrimTrailingWhitespace(page_count);

            if (IsValidBookInput(title, author, genre, publisher, page_count)) {
                addBookMsg["title"] = title;
                addBookMsg["author"] = author;
                addBookMsg["genre"] = genre;
                addBookMsg["page_count"] = stoi(page_count);
                addBookMsg["publisher"] = publisher;

                char* request = ComputePostRequest(host, url, contentType,
                        addBookMsg.dump(), cookies, jwtToken);
                sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
                SendToServer(sockfd, request);
                char* reply = ReceiveFromServer(sockfd);

                if (strstr(reply, "error")) {
                    cout << "You do not have access to the library." << endl;
                } else if (strstr(reply, "Too many")) {
                    cout << "Could not add book." << endl;
                } else {
                    cout << "Succesfully added book." << endl;
                }

                CloseConnection(sockfd);
                FreeBuffers(request, reply);
            } else {
                cout << "Wrong input data for a new book." << endl;
            }
        } else if (command == "delete_book") {
            string id;
            cout << "id=";
            getline(cin, id);
            id = TrimTrailingWhitespace(id);

            if (IsNumeric(id)) {
                char* url = (char* )calloc(URLMAXLEN, sizeof(char));
                sprintf(url, "/api/v1/tema/library/books/%s", id.c_str());

                char* request = ComputeDeleteRequest(host, (const char* ) url,
                        cookies, jwtToken);
                sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
                SendToServer(sockfd, request);
                char* reply = ReceiveFromServer(sockfd);

                if (strstr(reply, "No book")) {
                    cout << "No book with id \"" << id << "\" was found deletable." << endl;
                } else if (strstr(reply, "error")) {
                    cout << "You do not have access to the library." << endl;
                } else {
                    cout << "Succesfully deleted book with id:" << id << "." << endl;
                }

                CloseConnection(sockfd);
                FreeBuffers(request, reply);
                free(url);
            } else {
                cout << "Book Id should be a numeric input." << endl;
            }
        } else if (command == "logout") {
            const char* url = "/api/v1/tema/auth/logout";
            char* request = ComputeGetRequest(host, url, cookies, "");
            sockfd = OpenConnection(addr, port, AF_INET, SOCK_STREAM, 0);
            SendToServer(sockfd, request);
            char* reply = ReceiveFromServer(sockfd);

            if (strstr(reply, "error")) {
                cout << "No account is logged in." << endl;
            } else {
                cout << "Logged out." << endl;
            }

            CloseConnection(sockfd);
            FreeBuffers(request, reply);
            cookies.erase();
            jwtToken.erase();
        } else if (command == "exit") {
            break;
        } else {
            cout << "Invalid command." << endl;
        }
    }

    return 0;
}
