Cotovanu Cristian 324CD

Project purpose:
    Implement a HTTP Client which can communicate with a server.
    
Implementation:
    Client reads input command from stdin, checks validity, offers prompt
    for specific command input data depending on command type, and then 
    computes and sends specific request.
    Connection to the server is being opened and closed for each request.
    Cookies and the JWT Token are contained in variables which update when
    there is a succesful request for either of them. On logout both cookies and
    the token reset.
    Whenever a request is succesful or not I show a suggestive message according 
    to the specific request to the console.
    Input data like username, password, id, etc from the console is being
    trimmed of its trailling whitespaces through a helper function.
    Input data validity is checked for various criterias: ids can only be numeric,
    title, author, publisher, genre can not contain numbers.
    JSON parsing was done using nlohmann for cpp.
    For books information output, I parsed the reply message and with json parser
    functionality extracted specific information.