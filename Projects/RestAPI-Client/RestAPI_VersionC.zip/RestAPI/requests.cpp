#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <string>
#include "connection.h"

using namespace std;

char* ComputeGetRequest(const char* host, const char* url,
                        const string &cookies, const string &jwtToken) {
    char* message = (char* )calloc(BUFF_LENGTH, sizeof(char));
    char* line = (char* )calloc(LINE_LENGTH + 1, sizeof(char));

    /// Step 1: Write the method name, URL, request params (if any) and protocol type
    sprintf(line, "GET %s HTTP/1.1", url);
    ComputeMessage(message, line);

    /// Step 2: Add the host
    sprintf(line, "Host: %s", host);
    ComputeMessage(message, line);

    /// Step 3: Add jwt token or cookies, according to the request format
    if (!cookies.empty()) {
        sprintf(line, "Cookie: %s", cookies.c_str());
        ComputeMessage(message, line);
    } else if (!jwtToken.empty()) {
        sprintf(line, "Authorization: Bearer %s", jwtToken.c_str());
        ComputeMessage(message, line);
    }

    /// Step 4: Add final new line
    ComputeMessage(message, "");
    free(line);
    return message;
}

char* ComputePostRequest(const char* host, const char* url,
                        const char* contentType, const string& bodyData,
                        const string& cookies, const string& jwtToken) {
    int bodyLen = bodyData.size();
    char* message = (char* )calloc(BUFF_LENGTH, sizeof(char));
    char* line = (char* )calloc(LINE_LENGTH, sizeof(char));

    /// Step 1: Write the method name, URL and protocol type
    sprintf(line, "POST %s HTTP/1.1", url);
    ComputeMessage(message, line);

    /// Step 2: Add the JWT token
    if (!jwtToken.empty()) {
        sprintf(line, "Authorization: Bearer %s", jwtToken.c_str());
        ComputeMessage(message, line);
    }

    /// Step 3: Add the host
    sprintf(line, "Host: %s", host);
    ComputeMessage(message, line);

    /// Step 4: add necessary headers (Content-Type and Content-Length are mandatory)
    sprintf(line, "Content-Type: %s", contentType);
    ComputeMessage(message, line);

    sprintf(line, "Content-Length: %d", bodyLen);
    ComputeMessage(message, line);

    /// Step 5: Add cookies
    if (!cookies.empty()) {
        sprintf(line, "Cookie: %s", cookies.c_str());
        ComputeMessage(message, line);
    }

    /// Step 6: Add newline
    sprintf(line, "%s", "");
    ComputeMessage(message, line);

    /// Step 7: Add the actual payload data
    ComputeMessage(message, bodyData.c_str ());

    memset(line, 0, LINE_LENGTH);
    free(line);
    return message;
}

char* ComputeDeleteRequest(const char* host, const char* url,
                           const string &cookies, const string &jwtToken) {
    char* message = (char* )calloc(BUFF_LENGTH, sizeof(char));
    char* line = (char* )calloc(LINE_LENGTH + 1, sizeof(char));

    /// Step 1: Write the method name, URL, request params (if any) and protocol type
    sprintf(line, "DELETE %s HTTP/1.1", url);
    ComputeMessage(message, line);

    /// Step 2: Add the host
    sprintf(line, "Host: %s", host);
    ComputeMessage(message, line);

    /// Step 3: Add headers and/or cookies, according to the protocol format
    if (!jwtToken.empty()) {
        sprintf(line, "Authorization: Bearer %s", jwtToken.c_str());
        ComputeMessage(message, line);
    }
    if (!cookies.empty()) {
        sprintf(line, "Cookie: %s", cookies.c_str());
        ComputeMessage(message, line);
    }

    /// Step 4: Add final new line
    ComputeMessage(message, "");
    free(line);
    return message;
}
