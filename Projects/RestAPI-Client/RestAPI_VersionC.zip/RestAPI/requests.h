#ifndef _REQUESTS_
#define _REQUESTS_

// computes and returns a GET request string
char *ComputeGetRequest(const char *host, const char *url,
                        const std::string &cookies, const std::string &jwtToken);

// computes and returns a POST request string
char* ComputePostRequest(const char *host, const char *url, const char *contentType,
                        const std::string& bodyData, const std::string& cookies,
                        const std::string& jwtToken);

char* ComputeDeleteRequest(const char *host, const char *url,
                           const std::string &cookies, const std::string &jwtToken);
#endif
